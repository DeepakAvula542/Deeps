package com.cts.onlineshop.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.onlineshop.Repository.UserRepository;
import com.cts.onlineshop.users.User;

@Service
public class UserService {
	@Autowired
	private UserRepository ur;
	
	public User create(User user) {
		return ur.save(user);
	}
	
	public User read(String name) {
		return ur.findById(name).get();
	}

	public List<User> read() {
		
		return ur.findAll();
	}

}
