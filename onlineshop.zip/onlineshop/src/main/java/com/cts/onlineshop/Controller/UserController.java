package com.cts.onlineshop.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.onlineshop.Service.UserService;
import com.cts.onlineshop.users.User;

@RestController
@CrossOrigin(origins = {"http://localhost:4200","*"})
public class UserController {
  
	@Autowired
	private UserService us;
	
	@PostMapping("/user")
	public User addUser(@RequestBody User user)
	{
		return us.create(user);
	}
	
	@GetMapping("/user/{name}/{password}")
	public User findUserById(@PathVariable String name, @PathVariable String password)
	{
		User user = us.read(name);
		if(user.getPassword().equals(password))
			return user;
		return null;
	}
	
	@GetMapping("/user")
	public List<User> getAllUsers()
	{
		return us.read();
	}
}
