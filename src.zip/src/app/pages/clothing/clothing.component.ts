import { Component, DoCheck, OnInit } from '@angular/core';
import { Cart } from '../../cart';
import { CartService } from '../../cart.service';
import { ClothingService } from '../../clothing.service';

@Component({
  selector: 'app-clothing',
  templateUrl: './clothing.component.html',
  styleUrls: ['./clothing.component.css']
})
export class ClothingComponent implements OnInit,DoCheck {
  clothings: any;

  constructor(private cls:ClothingService, private cartService:CartService) { }
  ngDoCheck(): void {

    
    
  }

  ngOnInit(): void {
    // this.cls.getAllClothings().subscribe((data)=>{
    //   console.log(data);
    //   this.clothings=data;
    // });
    this.cls.findProductByCategory().subscribe((data)=>{
      console.log(data);
      // alert(data);
      this.clothings=data;});
  }

  fnAddToCart(id:any, price:any)
  {
    // alert(id);
    if(localStorage.getItem('customer')==null)
    {
      console.log("NOt logged in.")
      return;
    }
    var str:any;
    str=localStorage.getItem('customer');
    var customer=JSON.parse(str);
    var customer_id=customer.id;
    var product_id=id;
    var pricee=price;
    var cart:Cart=new Cart();
    cart.id=0;      //dummy
    cart.customer_id=customer_id;
    cart.product_id=product_id;
    console.log("sending the below cart object to rest api now:");
    console.log(cart);
    this.cartService.add2Cart(customer_id,product_id,pricee).subscribe((data)=>{
      console.log(data);
      alert('Id ' +id+ ' added to cart');
    });
  }

}
