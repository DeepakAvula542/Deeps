import { Component, DoCheck, OnInit } from '@angular/core';
import { BookService } from 'src/app/book.service';
import { Cart } from 'src/app/cart';
import { CartService } from 'src/app/cart.service';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit,DoCheck {
  books:any;

  constructor(private bs:BookService, private cartService:CartService) { }
  ngDoCheck(): void {
    
  }

  ngOnInit(): void {
    this.bs.getAllBooks().subscribe((data)=>{
      console.log(data);
      this.books=data;});
  }

  fnAddToCart(id:any)
  {
    // alert(id);
    if(localStorage.getItem('customer')==null)
    {
      console.log("NOt logged in.")
      return;
    }
    var str:any;
    str=localStorage.getItem('customer');
    var customer=JSON.parse(str);
    var customer_id=customer.id;
    var product_id=id;
    var cart:Cart=new Cart();
    cart.id=0;      //dummy
    cart.customer_id=customer_id;
    cart.product_id=product_id;
    console.log("sending the below cart object to rest api now:");
    console.log(cart);
    this.cartService.add2Cart(customer_id,product_id).subscribe((data)=>{
      console.log(data);
      alert('Id ' +id+ ' added to cart');
    });
  }

}
