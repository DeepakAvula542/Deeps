import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ProductService } from '../../product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  productForm:any;
  selectedFile:any;
  products:any;
  constructor(private fb:FormBuilder, private ps:ProductService) {
    this.productForm=this.fb.group({
      id:[],
      name:[],
      category:[],
      price:[],
      image:[]
    });
   }

  ngOnInit(): void {
    
    this.ps.getAllProducts().subscribe((data)=>{
      this.products=data;
    });
  }

  onFileChanged(event:any)
  {
    this.selectedFile=event.target.files[0];
    console.log(JSON.stringify(this.selectedFile));
  }
  onUpload()
  {
    console.log(this.selectedFile);
    
    //FormData API provides methods and properties to allow us easily prepare form data to be sent with POST HTTP requests.
    const x = new FormData();
    x.append('id',this.productForm.controls['id'].value);
    x.append('name',this.productForm.controls['name'].value);
    x.append('category',this.productForm.controls['category'].value);
    x.append('price',this.productForm.controls['price'].value);
    
    x.append('image', this.selectedFile, this.selectedFile.name);
    console.log(x);

    this.ps.addProduct(x).subscribe((data)=>{
      console.log(data);
      alert("Product successfully added")
    })
    // this.http.post('http://localhost:8080/image/upload',uploadImageData).subscribe(data=>console.log(data));
  }
  onDelete()
  {

    this.ps.removeProduct(this.productForm.controls['id'].value).subscribe((data)=>{
      console.log(data);
    })
  }
  
}
