import { Component, OnInit } from '@angular/core';
//import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/customer.service';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm: any;

  constructor(private fb:FormBuilder, private cs:CustomerService, private route:Router) {
    this.signupForm=this.fb.group({
      id:['',[Validators.required]],
      firstName:['',[Validators.required]],
      lastName:['',[Validators.required]],
      password:['',[Validators.required, Validators.minLength(5), Validators.maxLength(15)]],
      cpassword:['',[Validators.required]],
      mobile:['',[Validators.required,Validators.pattern("^((\\+91-?)|0)?[0-9]{10}$"),Validators.minLength(10)]],
      email:['',[Validators.required]],
    },
    {
      validator: this.confirmedValidator('password','cpassword')
    });
   }

  ngOnInit(): void {
  }


  confirmedValidator(controlName: string, matchingControlName: string){
    return (formGroup: FormGroup) => {
        const control = formGroup.controls[controlName];
        const matchingControl = formGroup.controls[matchingControlName];
        if (matchingControl.errors && !matchingControl.errors.confirmedValidator) {
            return;
        }
        if (control.value !== matchingControl.value) {
            matchingControl.setErrors({ confirmedValidator: true });
        } else {
            matchingControl.setErrors(null);
        }
    }
  }
  get f()
  {
    return this.signupForm.controls;
  }

  fn1()
  {
    console.log(this.signupForm.value);
  }
  signup()
  {
    var customer=this.signupForm.value;
    console.log("We are sending the below object to rest api.");
    console.log(customer);
    this.cs.signup(customer).subscribe(data=>console.log(data));
    this.route.navigate(["/login"]);
    alert("SignUp Successful")
    // var mycustomer=new MyCustomer();
    // mycustomer.id=this.signupForm.controls['id'].value;
    // mycustomer.password=this.signupForm.controls['password'].value;
    // this.cs.signup(mycustomer).subscribe(data=>console.log(data));
  }
 
 
}
