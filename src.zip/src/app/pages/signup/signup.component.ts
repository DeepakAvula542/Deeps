import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { CustomerService } from 'src/app/customer.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  signupForm: any;

  constructor(private fb:FormBuilder, private cs:CustomerService, private route:Router) {
    this.signupForm=this.fb.group({
      id:[],
      firstName:[],
      lastName:[],
      password:[],
      mobile:[],
      email:[]
    });
   }

  ngOnInit(): void {
  }
  signup()
  {
    var customer=this.signupForm.value;
    console.log("We are sending the below object to rest api.");
    console.log(customer);
    this.cs.signup(customer).subscribe(data=>console.log(data));
    this.route.navigate(["/login"]);
    // var mycustomer=new MyCustomer();
    // mycustomer.id=this.signupForm.controls['id'].value;
    // mycustomer.password=this.signupForm.controls['password'].value;
    // this.cs.signup(mycustomer).subscribe(data=>console.log(data));
  }

}
