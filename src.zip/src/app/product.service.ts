import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  getCategories() {
    throw new Error('Method not implemented.');
  }
  removeProduct(id: any) {
    return this.http.delete(this.url+"/"+id);
  }
  url:string='http://localhost:8080/product';

  constructor(private http:HttpClient) { }

  addProduct(x:any)
  {
    return this.http.post(this.url,x);
  }

  getAllProducts()
  {
    return this.http.get(this.url);
  }
}
