import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  url:string='http://localhost:8080/order';
  constructor(private http:HttpClient) { }

  removeFromCart(id:any)
  {
    return this.http.delete(this.url+"/"+id);
  }
}
