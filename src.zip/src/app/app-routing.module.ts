import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LogoutComponent } from './pages/logout/logout.component';
// import { HomeComponent } from './home/home.component';
import { BookComponent } from './pages/book/book.component';
import { CartComponent } from './pages/cart/cart.component';

import { LoginComponent } from './pages/login/login.component';
import { SignupComponent } from './pages/signup/signup.component';
import { ProductComponent } from './product/product.component';
import { ElectronicsComponent } from './electronics/electronics.component';
import { ClothingComponent } from './clothing/clothing.component';
import { PaymentComponent } from './payment/payment.component';
import { FooterComponent } from './footer/footer.component';

const routes: Routes = [
  {path:'login', component:LoginComponent},
  {path:'signup', component:SignupComponent},
  {path:'home', component:HomeComponent},
  {path:'books', component:BookComponent},
  {path:'product', component:ProductComponent},
  {path:'cart', component:CartComponent},
  {path:'logout', component:LogoutComponent},
  {path:'electronics', component:ElectronicsComponent},
  {path:'clothings', component:ClothingComponent},
  {path:'payment', component:PaymentComponent},
  {path:'footer', component:FooterComponent}
  // {path:'loginbutton', component:HomeComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
