package com.OnlineShopping.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.OnlineShopping.entity.Product;
import com.OnlineShopping.service.ProductService;



@RestController
@CrossOrigin({"http://localhost:4200","*"})
public class ProductController {
	@Autowired
	private ProductService ps;
	
	@PostMapping("/product")
//	public int signup(@RequestBody Product product)
	public int addProduct(@RequestParam Long id,@RequestParam String name,@RequestParam String category,@RequestParam Double price,@RequestParam("image") MultipartFile file) throws IOException
	{
		byte[] image=file.getBytes();
		Product product=new Product(id, name, category, price, image);
		return ps.create(product);
	}
	
	@GetMapping("/product")
	public List<Product> getAllProducts()
	{
		return ps.read();
	}
	
	@GetMapping("/product/{id}")
	public Product findProductById(@PathVariable Long id)
	{
		return ps.read(id);
	}
	
	@GetMapping("/product/{category}")
	public Product findProductByCategory(@PathVariable String category)
	{
		return ps.read(category);
	}
	
	@GetMapping("/product/category/{category}")
	public List<Product> findProductsByCategory(@PathVariable String category)
	{
		return ps.findProductsByCategory(category);
	}
	
	@GetMapping("/product/categories")
	public List<String> getCategories()
	{
		return ps.getCategories();
	}
	
	@GetMapping("/product/category/books/books")
	public List<String> getAllBooks()
	{
		return ps.getAllBooks();
	}
	
	@GetMapping("/product/category/clothing/clothing")
	public List<String> getAllClothings()
	{
		return ps.getAllClothings();
	}
	
	@PutMapping("/product")
	public int modifyProduct(@RequestBody Product product)
	{
		return ps.update(product);
	}
	
	@DeleteMapping("/product/{id}")
	public int removeProduct(@PathVariable Long id)
	{
		return ps.delete(id);
	}
}

