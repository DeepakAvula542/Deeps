package com.OnlineShopping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.OnlineShopping.entity.Cart;
import com.OnlineShopping.entity.Customer;
import com.OnlineShopping.entity.Product;
import com.OnlineShopping.service.CartService;
import com.OnlineShopping.service.CustomerService;
import com.OnlineShopping.service.ProductService;

@RestController
@CrossOrigin({"http://localhost:4200","*"})
public class CartController {
	@Autowired
	private CartService cs;
	@Autowired
	private CustomerService customerService;
	@Autowired
	private ProductService ps;
	
	private Long generateCartId()
	{
		List<Cart> carts = getAllCarts();
		if(carts.size()==0)
		{
			return 1L;
		}
		Long lastIndex=carts.get(carts.size()-1).getId();
		return lastIndex+1;
	}
	
	@PostMapping("/cart/{cid}/{pid}/{price}")
	public int add2Cart(@PathVariable("cid") Long customerId, @PathVariable("pid") Long productId, @PathVariable("price") Long price)
	{
		Customer customer=customerService.read(customerId);
		Product product=ps.read(productId);
		Long id=generateCartId();
		Cart cart=new Cart(id, customerId, productId,price);
		cart.setId(id);
		System.out.println("Cart Controller: 38th line: "+cart);
		
		return cs.create(cart);
	}
	
	@GetMapping("/cart")
	public List<Cart> getAllCarts()
	{
		return cs.read();
	}
	
	@GetMapping("/customer/cart/{id}")
	public List<Cart> readByCustomerId(@PathVariable Long id)
	{
		return cs.readByCustomerId(id);
	}
	
	@GetMapping("/cart/customer/{id}")
	public List<Cart> findCartItemsByCustomerId(@PathVariable Long id)
	{
		return cs.findCartItemsByCustomerId(id);
	}
	
	@GetMapping("/cart/{id}")
	public Cart findCartById(@PathVariable Long id)
	{
		return cs.read(id);
	}
	
	
	@PutMapping("/cart")
	public int modifyCart(@RequestBody Cart cart)
	{
		return cs.update(cart);
	}
	
	@DeleteMapping("/cart/{id}")
	public int removeCart(@PathVariable Long id)
	{
		return cs.delete(id);
	}
}
