package com.OnlineShopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OnlineShopping.dao.CustomerDao;
import com.OnlineShopping.entity.Customer;

@Service
public class CustomerService {
	
		@Autowired
		private CustomerDao cdao;
		
		public int create(Customer customer)
		{
			return cdao.create(customer);
		}

		public List<Customer> read()
		{
			return cdao.read();
		}

		public Customer read(Long id)
		{
			return cdao.read(id);
		}

		public int update(Customer customer)
		{
			return cdao.update(customer);
		}

		public int delete(Long id)
		{
			return cdao.delete(id);
		}
	}

