package com.OnlineShopping.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.OnlineShopping.dao.OrderDao;
import com.OnlineShopping.entity.Order;

@Service
public class OrderService {
	@Autowired
	private OrderDao odao;
	
	public int create(Order order)
	{
		return odao.create(order);
	}

	public List<Order> read()
	{
		return odao.read();
	}

	public Order read(Long id)
	{
		return odao.read(id);
	}

	public int update(Order order)
	{
		return odao.update(order);
	}

	public int delete(Long id)
	{
		return odao.delete(id);
	}
	
	public List<Order> findOrdersByCustomer(Long customer_id)
	{
		return odao.findOrdersByCustomer(customer_id);
	}
}
