package com.OnlineShopping.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.OnlineShopping.entity.Order;

@Component
public class OrderDaoImpl implements OrderDao{
	
	@Autowired
	 public JdbcTemplate jdbcTemplate;
	 
	@Override
	public int create(Order order) {
		return jdbcTemplate.update("INSERT INTO ORDER_DETAILS VALUES (?,?,?,?,?)", order.getOrderId(), order.getOrderDate(), order.getProduct_Id(), order.getCustomer_Id(), order.getQuantity());
	}

	@Override
	public List<Order> read() {
		return jdbcTemplate.query("SELECT * FROM ORDER_DETAILS", new OrderRowMapper());
	}
	
	
	@Override
	public Order read(Long id) {
		return jdbcTemplate.queryForObject("SELECT * FROM ORDER_DETAILS WHERE id=?", new OrderRowMapper(), id);
	}
	@Override
	public List<Order> findOrdersByCustomer(Long customer_id)
	{
		return jdbcTemplate.query("SELECT * FROM ORDER_DETAILS WHERE customer_id=?", new OrderRowMapper(), customer_id);
	}
	
	
	@Override
	public int update(Order order) {
		return jdbcTemplate.update("UPDATE ORDER_DETAILS SET orderDate=?, product_id=?, customer_id=?, quantity WHERE id=?", order.getOrderDate(), order.getProduct_Id(), order.getCustomer_Id(), order.getQuantity(), order.getOrderId());
	}
	
	
	@Override
	public int delete(Long id) {
		return jdbcTemplate.update("DELETE FROM ORDER_DETAILS WHERE id=?",id);
	}
}
