package com.OnlineShopping.dao;

import java.util.List;

import com.OnlineShopping.entity.Order;

public interface OrderDao {
	
	int create(Order order);

	List<Order> read();

	Order read(Long id);

	int update(Order order);

	int delete(Long id);

	List<Order> findOrdersByCustomer(Long customer_id);

}
