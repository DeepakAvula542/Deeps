package com.OnlineShopping.dao;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.OnlineShopping.entity.Product;


@Component
public class ProductDaoImpl implements ProductDao {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	
	@Override
	public int create(Product product) {
		return jdbcTemplate.update("INSERT INTO PRODUCT VALUES (?,?,?,?,?)", product.getId(), product.getName(), product.getCategory(), product.getPrice(), product.getImage());
	}
	
	@Override
	public List<Product> read() {
		return jdbcTemplate.query("SELECT * FROM PRODUCT", new ProductRowMapper());
	}
	
	@Override
	public Product read(Long id) {
		return jdbcTemplate.queryForObject("SELECT * FROM PRODUCT WHERE id=?", new ProductRowMapper(), id);
	}
	
	@Override
	public Product read(String category) {
		return jdbcTemplate.queryForObject("SELECT * FROM PRODUCT WHERE category=?", new ProductRowMapper(), category);
	}
	
	@Override
	public List<String> getCategories()
	{
		return jdbcTemplate.query("SELECT DISTINCT category FROM PRODUCT",new CategoryRowMapper());	
	}
	
	public List<String> getAllBooks()
	{
		return jdbcTemplate.query("SELECT * FROM PRODUCT WHERE upper(category)='book'", new CategoryRowMapper());
	}
	
	public List<String> getAllClothings()
	{
		return jdbcTemplate.query("SELECT * FROM PRODUCT WHERE upper(category)='clothing'", new CategoryRowMapper());
	}
	
	@Override
	public int update(Product product) {
		if(product.getImage().length>0)
			return jdbcTemplate.update("UPDATE PRODUCT SET name=?, category=?, price=?, image=? WHERE id=?", product.getName(), product.getCategory(), product.getPrice(), product.getId(), product.getImage());
		return jdbcTemplate.update("UPDATE PRODUCT SET name=?, category=?, price=? WHERE id=?", product.getName(), product.getCategory(), product.getPrice(), product.getId());
	}
	
	@Override
	public int delete(Long id) {
		return jdbcTemplate.update("DELETE FROM PRODUCT WHERE id=?",id);
	}
	
	@Override
	public List<Product> findProductsByCategory(String category)
	{
		return jdbcTemplate.query("SELECT * FROM PRODUCT WHERE category=?", new ProductRowMapper(), category);
	}

	
	
}
